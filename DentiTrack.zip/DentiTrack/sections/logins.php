<section id="logins">
  <h2 class="section-title">Logins</h2>
  <div class="login-options">
    
    <div class="login-box">
      <img src="images/patient.jpg" alt="Patient Login">
      <h3>Patient Login</h3>
      <a href="auth/patient_login.php" class="login-btn">Click Here</a>
    </div>

    <div class="login-box">
      <img src="images/doctor.jpg" alt="Doctor Login">
      <h3>Doctors Login</h3>
      <a href="auth/doctor_login.php" class="login-btn">Click Here</a>
    </div>

    
    <div class="login-box">
      <img src="images/secretary.jpg" alt="Secretary Login">
      <h3>Secretary Login</h3>
      <a href="auth/secretary_login.php" class="login-btn">Click Here</a>
    </div>

    <div class="login-box">
      <img src="images/admin.jpg" alt="Admin Login">
      <h3>Admin Login</h3>
      <a href="auth/admin_login.php" class="login-btn">Click Here</a>
    </div>

  </div>
</section>
