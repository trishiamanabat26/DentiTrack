<h2 class="section-title">Our Dental Services</h2>

<div class="services-container">
    <div class="service-card">
        <img src="images/checkup.jpg" alt="Dental Checkup">
        <h3>Dental Checkup</h3>
        <p>Routine oral exams to ensure healthy teeth and gums.</p>
    </div>

    <div class="service-card">
        <img src="images/extraction.jpg" alt="Tooth Extraction">
        <h3>Tooth Extraction</h3>
        <p>Safe and gentle tooth removal when necessary.</p>
    </div>

    <div class="service-card">
        <img src="images/whitening.jpg" alt="Teeth Whitening">
        <h3>Teeth Whitening</h3>
        <p>Brighten your smile with our whitening treatments.</p>
    </div>

    <div class="service-card">
        <img src="images/braces.jpg" alt="Braces Installation">
        <h3>Braces Installation</h3>
        <p>Improve teeth alignment with our orthodontic services.</p>
    </div>

    <div class="service-card">
        <img src="images/cleaning.jpg" alt="Cleaning & Polishing">
        <h3>Cleaning & Polishing</h3>
        <p>Professional dental cleaning for a fresher mouth.</p>
    </div>

    <div class="service-card">
        <img src="images/rootcanal.jpg" alt="Root Canal">
        <h3>Root Canal Treatment</h3>
        <p>Treat infected pulp and save your natural teeth.</p>
    </div>
</div>
