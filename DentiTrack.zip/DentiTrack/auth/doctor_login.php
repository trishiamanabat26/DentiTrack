<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DentiTrack Login</title>
  <link rel="stylesheet" href="css/patient_form.css">
</head>
<body>
  <div class="auth-wrapper">
    <div class="auth-container">
      <!-- Login Form -->
      <div class="form-card" id="login-form">
        <h2>🦷 DentiTrack Login</h2>
        <form action="process_login.php" method="POST">
          <input type="text" name="username" placeholder="Username" required>
          <input type="password" name="password" placeholder="Password" required>
          <button type="submit">Login</button>
          <!-- Forgot Password Link -->
          <p><a href="#" onclick="toggleForm('forgot-password')">Forgot Password?</a></p>
        </form>
      </div>

      <!-- Forgot Password Form -->
      <div class="form-card hidden" id="forgot-password-form">
        <h2>Reset Password</h2>
        <form action="process_forgot_password.php" method="POST">
          <input type="email" name="email" placeholder="Enter your email" required>
          <button type="submit">Send Reset Link</button>
        </form>
        <p>Remembered your password? <a href="#" onclick="toggleForm('login')">Login here</a></p>
      </div>

      <!-- Reset Password Form -->
      <div class="form-card hidden" id="reset-password-form">
        <h2>Create New Password</h2>
        <form action="process_reset_password.php" method="POST">
          <input type="password" name="new_password" placeholder="New Password" required>
          <input type="password" name="confirm_new_password" placeholder="Confirm New Password" required>
          <button type="submit">Reset Password</button>
        </form>
        <p>Remembered your password? <a href="#" onclick="toggleForm('login')">Login here</a></p>
      </div>

    </div>
  </div>
  <button class="back-button" onclick="goBack()">← Back</button>

  <script>
  function goBack() {
    window.history.back(); // Navigates to the previous page
  }

  function toggleForm(formType) {
    const loginForm = document.getElementById("login-form");
    const forgotPasswordForm = document.getElementById("forgot-password-form");
    const resetPasswordForm = document.getElementById("reset-password-form");

    // Hide all forms
    loginForm.classList.add("hidden");
    forgotPasswordForm.classList.add("hidden");
    resetPasswordForm.classList.add("hidden");

    // Show the selected form
    if (formType === 'forgot-password') {
      forgotPasswordForm.classList.remove("hidden");
    } else if (formType === 'reset-password') {
      resetPasswordForm.classList.remove("hidden");
    } else {
      loginForm.classList.remove("hidden");
    }
  }
  </script>
</body>
</html>
