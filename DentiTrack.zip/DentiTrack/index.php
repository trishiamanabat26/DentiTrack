<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DentiTrack</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- Navigation Bar -->
    <header>
        <nav>
            <div class="logo">DentiTrack</div>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="#logins">Logins</a></li>
                <li><a href="#booknow" class="book-now">Book Now</a></li>
            </ul>
        </nav>
    </header>

    <!-- Sections -->
    <section id="home"><?php include("sections/home.php"); ?></section>
    <section id="services"><?php include("sections/services.php"); ?></section>
    <section id="about"><?php include("sections/about.php"); ?></section>
    <section id="contact"><?php include("sections/contact.php"); ?></section>
    <section id="logins"><?php include("sections/logins.php"); ?></section>
    <section id="booknow"><?php include("sections/booknow.php"); ?></section>

</body>
</html>
